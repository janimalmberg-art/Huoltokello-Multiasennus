"""Selainkäyttöliittymä."""
