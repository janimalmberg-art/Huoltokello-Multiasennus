/* Huoltokello-dokumentaatio: kevyt syntaksikorostus + keltainen rivikorostus (data-hl="12-15,23") */
(function () {
  'use strict';
  function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function parseRanges(str) {
    var set = new Set(); if (!str) return set;
    str.split(',').forEach(function (p) {
      p = p.trim(); if (!p) return;
      if (p.indexOf('-') >= 0) { var a = p.split('-'); for (var i = +a[0]; i <= +a[1]; i++) set.add(i); }
      else set.add(+p);
    });
    return set;
  }
  /* Kaikissa kielissä ryhmät: 1=kommentti, 2=merkkijono, 3=luku, 4=avainsana */
  var RULES = {
    cs: /(\/\/.*$)|("(?:\\.|[^"\\])*")|(\b\d[\d_]*(?:\.\d+)?[mdMDfF]?\b)|(\b(?:using|namespace|var|public|private|protected|internal|static|readonly|const|class|record|enum|interface|partial|sealed|new|return|if|else|foreach|for|while|do|switch|case|default|break|continue|try|catch|finally|throw|await|async|null|true|false|string|int|long|double|decimal|bool|void|object|this|base|override|virtual|out|in|ref|is|as|not|and|or|get|set)\b)/g,
    js: /(\/\/.*$)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(\b\d+(?:\.\d+)?\b)|(\b(?:function|const|let|var|return|if|else|for|while|do|new|true|false|null|try|catch|typeof|this|document|window|navigator|addEventListener|async|await|switch|case|break|default)\b)/g,
    json: /("(?:\\.|[^"\\])*")|(\b(?:true|false|null)\b)|(-?\b\d+(?:\.\d+)?\b)|()/g,
    ps: /(#.*$)|("[^"]*")|(-?\b\d+(?:\.\d+)?\b)|(\b(?:az|dotnet|powershell|winget|param|if|else|foreach|try|catch|return|function|Get-ChildItem|Remove-Item|Add-Type)\b)/g,
    yaml: /(#.*$)|("[^"]*")|(\b\d+(?:\.\d+)?\b)|(\b(?:on|push|branches|name|jobs|runs-on|steps|uses|with|run|workflow_dispatch)\b)/g
  };
  function mark(line, lang) {
    var re = RULES[lang] || RULES.cs;
    re.lastIndex = 0;
    var out = '', i = 0, m;
    while ((m = re.exec(line)) !== null) {
      if (m[0].length === 0) { re.lastIndex++; continue; }
      out += esc(line.slice(i, m.index));
      if (m[1] !== undefined) out += '<span class="c">' + esc(m[1]) + '</span>';
      else if (m[2] !== undefined) out += '<span class="s">' + esc(m[2]) + '</span>';
      else if (m[3] !== undefined) out += '<span class="n">' + esc(m[3]) + '</span>';
      else if (m[4] !== undefined) out += '<span class="k">' + esc(m[4]) + '</span>';
      i = m.index + m[0].length;
    }
    out += esc(line.slice(i));
    return out;
  }
  document.querySelectorAll('pre[data-lang] code').forEach(function (code) {
    var pre = code.parentElement;
    var lang = pre.getAttribute('data-lang') || 'cs';
    var hl = parseRanges(pre.getAttribute('data-hl') || '');
    var text = code.textContent.replace(/\r\n/g, '\n');
    if (text.charAt(text.length - 1) === '\n') text = text.slice(0, -1);
    var lines = text.split('\n');
    code.innerHTML = lines.map(function (line, i) {
      var h = mark(line, lang);
      return hl.has(i + 1) ? '<span class="hl-line">' + h + '</span>' : h;
    }).join('\n');
  });
})();