// Huoltokello – offline-kirjausjono (v2.2.0).
// Kuittauslomake tallentaa kirjauksen IndexedDB-jonoon, kun verkko on katkennut;
// jono lähtee automaattisesti, kun verkko palaa (tai "Lähetä nyt" -painikkeesta).
// Tieto säilyy selaimen pysyvässä muistissa myös selaimen sulkemisen yli.
(function () {
    'use strict';
    var DB = 'hk-offline', STORE = 'queue';
    var dbp = null, sending = false, pill = null, pillText = null, pillClear = null;
    var pending = -1;

    // ---------- IndexedDB-apurit ----------
    function openDb() {
        if (dbp) return dbp;
        dbp = new Promise(function (resolve, reject) {
            var req = indexedDB.open(DB, 1);
            req.onupgradeneeded = function () { req.result.createObjectStore(STORE, { keyPath: 'id' }); };
            req.onsuccess = function () { resolve(req.result); };
            req.onerror = function () { reject(req.error || new Error('IndexedDB ei ole käytettävissä')); };
        });
        return dbp;
    }
    function getAll() {
        return openDb().then(function (db) {
            return new Promise(function (res, rej) {
                var r = db.transaction(STORE, 'readonly').objectStore(STORE).getAll();
                r.onsuccess = function () { res(r.result || []); };
                r.onerror = function () { rej(r.error); };
            });
        });
    }
    function putItem(it) {
        return openDb().then(function (db) {
            return new Promise(function (res, rej) {
                var tx = db.transaction(STORE, 'readwrite');
                tx.objectStore(STORE).put(it);
                tx.oncomplete = function () { res(); };
                tx.onerror = function () { rej(tx.error); };
            });
        });
    }
    function delItem(id) {
        return openDb().then(function (db) {
            return new Promise(function (res, rej) {
                var tx = db.transaction(STORE, 'readwrite');
                tx.objectStore(STORE).delete(id);
                tx.oncomplete = function () { res(); };
                tx.onerror = function () { rej(tx.error); };
            });
        });
    }
    function clearAll() {
        return openDb().then(function (db) {
            return new Promise(function (res, rej) {
                var tx = db.transaction(STORE, 'readwrite');
                tx.objectStore(STORE).clear();
                tx.oncomplete = function () { res(); };
                tx.onerror = function () { rej(tx.error); };
            });
        });
    }

    function uuid() {
        if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
        return 'hk-' + Date.now() + '-' + Math.random().toString(16).slice(2);
    }
    function readDataUrl(f) {
        return new Promise(function (res, rej) {
            var r = new FileReader();
            r.onload = function () { res(r.result); };
            r.onerror = function () { rej(r.error); };
            r.readAsDataURL(f);
        });
    }
    function dataUrlToBlob(d) { return fetch(d).then(function (r) { return r.blob(); }); }

    // ---------- statuspalkki ----------
    function ensurePill() {
        if (pill) return;
        pill = document.createElement('div');
        pill.className = 'hk-offline-pill';
        pill.setAttribute('role', 'status');
        pillText = document.createElement('span');
        var send = document.createElement('button');
        send.type = 'button';
        send.className = 'btn btn-light btn-sm';
        send.textContent = 'Lähetä nyt';
        send.addEventListener('click', function () { trySend(); });
        pillClear = document.createElement('button');
        pillClear.type = 'button';
        pillClear.className = 'btn btn-link btn-sm text-white p-0';
        pillClear.textContent = 'Tyhjennä';
        pillClear.title = 'Poista odottavat kirjaukset tältä laitteelta';
        pillClear.addEventListener('click', function () {
            if (confirm('Poistetaanko odottavat kirjaukset tältä laitteelta? Lähettämättömät tiedot katoavat.')) {
                clearAll().then(function () { refreshCount(); });
            }
        });
        pill.appendChild(pillText);
        pill.appendChild(send);
        pill.appendChild(pillClear);
        document.body.appendChild(pill);
    }

    function updatePill() {
        ensurePill();
        if (pending > 0) {
            pillText.textContent = (sending ? '⏳ Lähetetään… ' : '📲 ') + pending + (pending === 1 ? ' kirjaus' : ' kirjausta') + (sending ? '' : ' odottaa verkkoa');
            pill.classList.remove('d-none');
        } else if (!navigator.onLine && document.getElementById('confirmForm')) {
            pillText.textContent = '📴 Olet offline — kuittaus tallentuu laitteelle';
            pill.classList.remove('d-none');
        } else {
            pill.classList.add('d-none');
        }
    }

    function refreshCount() {
        getAll().then(function (items) { pending = items.length; updatePill(); })
                .catch(function () { pending = 0; updatePill(); });
    }
    // ---------- lähetysjono ----------
    function buildForm(it) {
        var fd = new FormData();
        (it.fields || []).forEach(function (kv) { fd.append(kv[0], kv[1]); });
        var step = Promise.all((it.photos || []).map(function (ph) {
            return dataUrlToBlob(ph.data).then(function (b) { fd.append(ph.key, b, ph.name || 'kuva.jpg'); });
        }));
        if (it.signature) {
            // Asiakkaan allekirjoitus (vaihe 3) palautetaan "signature"-tiedostoksi
            step = step.then(function () {
                return dataUrlToBlob(it.signature).then(function (b) { fd.append('signature', b, 'asiakkaan-allekirjoitus.png'); });
            });
        }
        return step.then(function () { return fd; });
    }

    function trySend() {
        if (sending) return;
        if (!navigator.onLine) { updatePill(); return; }
        sending = true;
        updatePill();
        sendNext();
    }

    function sendNext() {
        getAll().then(function (items) {
            pending = items.length;
            updatePill();
            if (!items.length) { sending = false; updatePill(); return; }
            items.sort(function (a, b) { return a.createdAt < b.createdAt ? -1 : 1; });
            var it = items[0];
            return buildForm(it).then(function (fd) {
                return fetch(it.action, { method: 'POST', body: fd, credentials: 'same-origin', redirect: 'follow' });
            }).then(function (resp) {
                var landed = (resp.url || '').toLowerCase();
                // Onnistunut kuittaus ohjautuu /Tasks/Details/… -sivulle
                if (resp.ok && landed.indexOf('/details/') !== -1) {
                    return delItem(it.id).then(function () { sendNext(); });
                }
                // Tehtävä ei ole enää kuittauskelpoinen (esim. kuitattu toisen toimesta) → pudotetaan jonosta
                if (resp.status === 404) {
                    return delItem(it.id).then(function () { sendNext(); });
                }
                sending = false;
                updatePill();
                if (landed.indexOf('/account/login') !== -1) {
                    alert('Kirjautuminen on vanhentunut. Kirjaudu uudelleen — odottavat kirjaukset säilyvät laitteella ja lähtevät uudelleenkirjautumisen jälkeen.');
                } else if (landed.indexOf('/confirm/') !== -1) {
                    alert('Odottavan kuittauksen tiedot eivät täsmää (esim. vaadittavat kentät ovat muuttuneet). Avaa tehtävä ja kuittaa uudelleen — tai tyhjennä jono "Tyhjennä"-painikkeella.');
                } else {
                    alert('Lähetys epäonnistui (HTTP ' + resp.status + '). Kirjaukset säilyvät laitteella ja yritetään uudelleen, kun verkko palaa.');
                }
            });
        }).catch(function () { sending = false; updatePill(); });
    }

    // ---------- kuittauslomakkeen sieppaus offline-tilassa ----------
    var form = document.getElementById('confirmForm');
    if (form) {
        form.addEventListener('submit', function (ev) {
            if (navigator.onLine) return; // verkko päällä: normaali lähetys
            ev.preventDefault();
            ev.stopPropagation();
            var fd = new FormData(form);
            var fields = [];
            var files = [];
            fd.forEach(function (val, key) {
                if (val instanceof window.File) {
                    if (val.size > 0 && val.name) files.push({ key: key, f: val });
                } else {
                    fields.push([key, val]);
                }
            });
            // Allekirjoitus (vaihe 3) otetaan suoraan kankaasta: tiedostokenttää ei ole vielä ehditty täyttää
            var sigData = null;
            try { sigData = (window.hkSigHasInk && window.hkSigHasInk() && window.hkSigDataUrl) ? window.hkSigDataUrl() : null; }
            catch (e) { sigData = null; }
            Promise.all(files.map(function (f) {
                return readDataUrl(f.f).then(function (d) { return { key: f.key, name: f.f.name || 'tiedosto', type: f.f.type, data: d }; });
            }))
                .then(function (photos) {
                    var item = { id: uuid(), createdAt: new Date().toISOString(), action: form.action, fields: fields, photos: photos };
                    if (sigData) item.signature = sigData;
                    return putItem(item);
                })
                .then(function () {
                    var note = document.createElement('div');
                    note.className = 'alert alert-success mt-3';
                    note.innerHTML = '<strong>📲 Kirjaus tallennettu laitteelle.</strong> Se lähetetään automaattisesti, kun verkko palaa — laite voi nyt siirtyä verkon kattavuuteen tai sulkeutua.';
                    var card = form.closest('.card-body') || form.parentElement;
                    card.insertBefore(note, form);
                    form.style.display = 'none';
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    refreshCount();
                })
                .catch(function (e) {
                    alert('Offline-tallennus epäonnistui: ' + (e && e.message ? e.message : e));
                });
        }, true); // capture: ajetaan ennen muuta lomakekäsittelyä
    }

    // ---------- tapahtumat ----------
    window.addEventListener('online', function () { trySend(); });
    window.addEventListener('offline', function () { updatePill(); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) trySend(); });
    setInterval(function () { if (!sending) trySend(); }, 60000);
    refreshCount();
})();
