// Huoltokello – yhteiset asiakasfunktiot: SignalR, ilmoituskello, tostit.

function showToast(title, text, kind) {
    const area = document.getElementById('toastArea');
    if (!area) return;
    const bg = kind === 'danger' ? 'bg-danger' : kind === 'warn' ? 'bg-warning text-dark' : 'bg-primary';
    const el = document.createElement('div');
    el.className = 'toast align-items-center text-white border-0 show';
    el.setAttribute('role', 'alert');
    el.innerHTML = `<div class="toast-header ${bg}"><strong class="me-auto small">${title}</strong>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button></div>
        <div class="toast-body small">${text}</div>`;
    area.appendChild(el);
    new bootstrap.Toast(el, { delay: 6000 }).show();
    el.addEventListener('hidden.bs.toast', () => el.remove());
}

// --- SignalR-asiakas: lataa paikallinen tiedosto tai CDN-varalataus ---
function loadSignalR(cb) {
    if (typeof signalR !== 'undefined') { cb(); return; }
    const local = document.createElement('script');
    local.src = '/lib/signalr/signalr.min.js';
    local.onload = () => typeof signalR !== 'undefined' ? cb() : loadCdn(cb);
    local.onerror = () => loadCdn(cb);
    document.head.appendChild(local);
    function loadCdn(done) {
        const cdn = document.createElement('script');
        cdn.src = 'https://cdnjs.cloudflare.com/ajax/libs/microsoft-signalr/8.0.0/signalr.min.js';
        cdn.onload = cb;
        document.head.appendChild(cdn);
    }
}

loadSignalR(function () {
    const c = new signalR.HubConnectionBuilder()
        .withUrl('/hubs/work')
        .withAutomaticReconnect()
        .build();
    window.workHub = c;

    c.on('taskUpdated', function (payload) {
        window.dispatchEvent(new CustomEvent('task-updated', { detail: payload }));
    });
    c.on('messageReceived', function (payload) {
        showToast((payload.type === 'Ohjeistus' ? '📋 Uusi ohjeistus' : '💬 Uusi viesti'),
            payload.title + (payload.sender ? ' – ' + payload.sender : ''));
        refreshNotifications();
    });
    c.on('contractReminder', function (payload) {
        showToast('📜 Sopimusmuistutus', payload.titles ? payload.titles.join(', ') : 'Sopimuksia vanhenemassa', 'warn');
        refreshNotifications();
    });
    c.on('notificationsChanged', function () {
        refreshNotifications();
    });

    c.start().then(function () {
        window.dispatchEvent(new Event('hubready'));
    }).catch(function (err) {
        setTimeout(function () { c.start(); }, 3000);
    });
});

// --- Ilmoituskello ---
async function refreshNotifications() {
    const badge = document.getElementById('notifBadge');
    const list = document.getElementById('notifList');
    if (!badge || !list) return;
    try {
        const res = await fetch('/Notifications/Api');
        const data = await res.json();
        if (data.unread > 0) {
            badge.textContent = data.unread;
            badge.classList.remove('d-none');
        } else {
            badge.classList.add('d-none');
        }
        if (!data.items.length) {
            list.innerHTML = '<div class="px-3 py-2 text-muted small">Ei ilmoituksia.</div>';
            return;
        }
        list.innerHTML = data.items.map(n => `
            <div class="notif-item ${n.isRead ? '' : 'unread'}">
                <a href="${n.link || '#'}" data-id="${n.id}" class="notif-link d-block">
                    <strong class="small">${n.title}</strong>
                    <div class="text-muted small">${n.message}</div>
                    <div class="text-muted" style="font-size:.7rem">${n.created}</div>
                </a>
            </div>`).join('');
        list.querySelectorAll('.notif-link').forEach(a =>
            a.addEventListener('click', () => fetch('/Notifications/MarkRead/' + a.dataset.id, { method: 'POST' })));
    } catch (e) { /* hiljaisesti */ }
}

const markAll = document.getElementById('notifMarkAll');
if (markAll) {
    markAll.addEventListener('click', async function () {
        await fetch('/Notifications/MarkAllRead', { method: 'POST' });
    });
}
if (document.getElementById('notifBadge')) refreshNotifications();

// --- Tumma tila (Bootstrap 5.3 data-bs-theme) ---
(function () {
    const btn = document.getElementById('themeToggle');
    if (!btn) return;
    function applyTheme(t) {
        if (t === 'dark') document.documentElement.setAttribute('data-bs-theme', 'dark');
        else document.documentElement.removeAttribute('data-bs-theme');
        btn.textContent = t === 'dark' ? '☀️' : '🌙';
    }
    applyTheme(localStorage.getItem('hk-theme') || 'light');
    btn.addEventListener('click', function () {
        const next = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
        localStorage.setItem('hk-theme', next);
        applyTheme(next);
    });
})();

// --- PWA: palvelutyöntekijän rekisteröinti (asennettavaksi aloitusnäytölle) ---
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register('/sw.js').catch(function () { /* ei kriittinen */ });
    });
}

// --- Prioriteettivärit alasvetovalikoissa (tehtävälomake, toistuvat tehtävät) ---
// Värjäää valikon taustan valitun prioriteetin mukaan ja reagoi muutoksiin.
(function () {
    function tint(sel) {
        sel.classList.remove('prio-0', 'prio-1', 'prio-2');
        sel.classList.add('prio-' + (sel.value === '' ? '1' : sel.value));
    }
    document.querySelectorAll('select.js-prio').forEach(function (sel) {
        tint(sel);
        sel.addEventListener('change', function () { tint(sel); });
    });
})();