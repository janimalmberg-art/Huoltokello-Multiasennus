// Huoltokello – PWA service worker (v2.4.0).
// Vaihe 2: sovelluskuori ja avatut sivut toimivat myös offline.
// Vaihe 3: Web Push -ilmoitukset (uusi tehtävä → ilmoitus laitteelle, myös sovelluksen ollessa kiinni).
const CACHE = 'hk-static-v4';
const PAGES = 'hk-pages-v1';
const LOCAL = [
    '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png',
    '/css/site.css', '/js/site.js', '/js/offline.js', '/js/push.js', '/js/jsQR.min.js', '/js/qrcode.min.js', '/js/calendar.js'
];
const CDN = [
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
    'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css'
];
const OFFLINE_HTML = '<!DOCTYPE html><html lang="fi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Huoltokello – offline</title></head><body style="font-family:system-ui,sans-serif;padding:2rem;text-align:center;color:#1e293b"><h2>📴 Olet offline</h2><p>Sivua ei ole tallennettu laitteelle.</p><p>Kirjaukset, jotka teet kuittauslomakkeella offline-tilassa, tallentuvat laitteelle ja lähetetään automaattisesti, kun verkko palaa.</p><p><a href="/Tasks">Kokeile Tehtävät-sivua →</a></p></body></html>';

self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE)
            .then((c) => Promise.all(LOCAL.concat(CDN).map((u) => c.add(u).catch(() => { /* yksittäinen tiedosto ei estä asennusta */ }))))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys()
            .then((keys) => Promise.all(keys.filter((k) => k !== CACHE && k !== PAGES).map((k) => caches.delete(k))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', (event) => {
    const req = event.request;
    if (req.method !== 'GET') return;
    const url = new URL(req.url);
    // SignalR ja health aina verkosta
    if (url.pathname.startsWith('/hubs') || url.pathname.startsWith('/health')) return;

    if (req.mode === 'navigate') {
        // Sivut: ensin verkko, päivitys välimuistiin, offline-tilassa välimuistista
        event.respondWith(
            fetch(req).then((res) => {
                if (res.ok) {
                    const copy = res.clone();
                    caches.open(PAGES).then((c) => c.put(req, copy));
                }
                return res;
            }).catch(() =>
                caches.open(PAGES).then((c) => c.match(req)).then((hit) =>
                    hit || new Response(OFFLINE_HTML, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })
                )
            )
        );
        return;
    }

    if (url.origin === self.location.origin) {
        // Staattiset saman lähteen tiedostot: cache-first
        event.respondWith(
            caches.open(CACHE).then((c) => c.match(req).then((hit) =>
                hit || fetch(req).then((res) => {
                    if (res.ok) c.put(req, res.clone());
                    return res;
                })
            ))
        );
    }
});

// ---------- Web Push (vaihe 3) ----------
self.addEventListener('push', (event) => {
    let data = {};
    try {
        data = event.data ? event.data.json() : {};
    } catch (e) {
        data = { title: 'Huoltokello', body: event.data ? event.data.text() : '' };
    }
    event.waitUntil(self.registration.showNotification(data.title || 'Huoltokello', {
        body: data.body || '',
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-192.png',
        tag: data.tag || 'hk-task',
        renotify: true,
        data: { url: data.url || '/Tasks' }
    }));
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    const url = (event.notification.data && event.notification.data.url) || '/Tasks';
    event.waitUntil(
        self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
            for (const c of list) {
                if ('focus' in c) { c.focus(); return; }
            }
            return self.clients.openWindow(url);
        })
    );
});