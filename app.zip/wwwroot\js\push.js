// Huoltokello – Web Push -tilaukset (vaihe 3).
// Navigaation 🔔/🔕 -painike: laitteelle sallitaan työilmoitukset, jolloin uudesta
// tehtävästä tulee ilmoitus myös silloin, kun sovellus ei ole auki.
(function () {
    'use strict';
    var btn = document.getElementById('pushToggle');
    if (!btn) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return;

    function b64ToUint8(b64) {
        var s = b64.replace(/-/g, '+').replace(/_/g, '/');
        while (s.length % 4) s += '=';
        var raw = atob(s);
        var arr = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
        return arr;
    }
    function setBtn(on) {
        btn.textContent = on ? '🔔' : '🔕';
        btn.title = on ? 'Ilmoitukset käytössä – poista käytöstä klikkaamalla'
                       : 'Salli työilmoitukset laitteelle (uusi tehtävä → ilmoitus)';
    }
    function current() {
        return navigator.serviceWorker.ready.then(function (reg) {
            return reg.pushManager.getSubscription().then(function (sub) { setBtn(!!sub); });
        }).catch(function () { /* esim. ei-HTTPS-ympäristö: painike jää taustalle */ });
    }

    btn.addEventListener('click', function () {
        navigator.serviceWorker.ready.then(function (reg) {
            return reg.pushManager.getSubscription().then(function (sub) {
                if (sub) {
                    return sub.unsubscribe().then(function () {
                        return fetch('/Push/Unsubscribe', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ endpoint: sub.endpoint }) });
                    }).then(function () { setBtn(false); alert('Ilmoitukset poistettu täältä laitteelta.'); });
                }
                return Notification.requestPermission().then(function (perm) {
                    if (perm !== 'granted') { alert('Selaimeen ei annettu lupaa ilmoituksille. Salli ilmoitukset selaimen asetuksista ja yritä uudelleen.'); return; }
                    return fetch('/Push/PublicKey').then(function (r) { return r.json(); }).then(function (k) {
                        if (!k || !k.key) throw new Error('VAPID-avain puuttuu palvelinasetuksista.');
                        return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToUint8(k.key) });
                    }).then(function (ns) {
                        var j = ns.toJSON();
                        return fetch('/Push/Subscribe', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ endpoint: j.endpoint, p256dh: j.keys.p256dh, auth: j.keys.auth })
                        });
                    }).then(function () { setBtn(true); alert('Ilmoitukset käytössä – saat ilmoituksen, kun sinulle luodaan uusi tehtävä.'); });
                });
            });
        }).catch(function (e) {
            alert('Ilmoitusten asettaminen ei onnistunut: ' + (e && e.message ? e.message : e));
        });
    });

    setBtn(false);
    current();
})();