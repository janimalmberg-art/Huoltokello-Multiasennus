// Vuosikellon renderöinti ja reaaliaikainen päivitys (SignalR).
(function () {
    const grid = document.getElementById('calendarGrid');
    if (!grid) return;

    let year = new Date().getFullYear();
    let todayStr = '';
    let refreshTimer = null;

    const fiMonths = ['Tammikuu', 'Helmikuu', 'Maaliskuu', 'Huhtikuu', 'Toukokuu', 'Kesäkuu',
        'Heinäkuu', 'Elokuu', 'Syyskuu', 'Lokakuu', 'Marraskuu', 'Joulukuu'];
    const dows = ['Ma', 'Ti', 'Ke', 'To', 'Pe', 'La', 'Su'];

    function val(id) {
        const el = document.getElementById(id);
        return el ? el.value : '';
    }

    function escapeHtml(s) {
        return (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    const prioNames = { 0: 'Matala', 1: 'Normaali', 2: 'Kiireellinen' };
    const prioDots = { 0: '🟢', 1: '', 2: '🔴' };

    function chipHtml(t) {
        const draggable = window.calendarIsManager
            ? ` draggable="true" data-id="${t.id}" `
            : '';
        const prioCls = (t.prio === 0 || t.prio === 2) ? ` prio-${t.prio}` : '';
        const prioDot = prioDots[t.prio] || '';
        return `<a class="chip ${t.css}${t.urgent ? ' urgent' : ''}${prioCls}" style="border-left-color:${t.color}"${draggable} ` +
            `href="/Tasks/Details/${t.id}" title="${escapeHtml(t.title)} — ${t.status} · ${t.site} · ${t.cat} · Kiireellisyys: ${prioNames[t.prio] || 'Normaali'}">` +
            `${escapeHtml(t.title)}${prioDot}</a>`;
    }

    function dayCell(dateStr, items) {
        let inner = '';
        const shown = Math.min(items.length, 3);
        for (let i = 0; i < shown; i++) inner += chipHtml(items[i]);
        if (items.length > 3) inner += `<span class="more-chips">+${items.length - 3} lisää</span>`;
        const cls = dateStr === todayStr ? ' today' : '';
        return `<div class="day${cls}" data-date="${dateStr}"><span class="dnum">${parseInt(dateStr.slice(8), 10)}</span>${inner}</div>`;
    }

    function render(data) {
        todayStr = data.today;
        document.getElementById('yearLabel').textContent = data.year;
        let html = '';
        for (const m of data.months) {
            const first = new Date(data.year, m.month - 1, 1);
            const lead = (first.getDay() + 6) % 7; // viikko alkaa maanantaista
            let cells = '';
            for (let i = 0; i < lead; i++) cells += '<div class="day empty"></div>';
            for (const d of m.days) cells += dayCell(d.date, d.tasks);
            html += `<div class="month-card"><div class="month-name">${fiMonths[m.month - 1]}</div>` +
                `<div class="dow">${dows.map(d => `<span>${d}</span>`).join('')}</div>` +
                `<div class="days">${cells}</div></div>`;
        }
        grid.innerHTML = html;
        enableDnd();
    }

    // --- Tehtävien raahaus päivältä toiselle (vain työnjohto) ---
    function enableDnd() {
        if (!window.calendarIsManager) return;
        const tokenInput = document.querySelector('input[name="__RequestVerificationToken"]');
        grid.querySelectorAll('.chip[draggable]').forEach(function (chip) {
            chip.addEventListener('dragstart', function (e) {
                e.dataTransfer.setData('text/plain', chip.dataset.id);
                e.dataTransfer.effectAllowed = 'move';
            });
        });
        grid.querySelectorAll('.day:not(.empty)').forEach(function (day) {
            day.addEventListener('dragover', function (e) {
                e.preventDefault();
                day.classList.add('drop-hover');
            });
            day.addEventListener('dragleave', function () { day.classList.remove('drop-hover'); });
            day.addEventListener('drop', async function (e) {
                e.preventDefault();
                day.classList.remove('drop-hover');
                const id = e.dataTransfer.getData('text/plain');
                const date = day.dataset.date;
                if (!id || !date) return;
                const body = new URLSearchParams({ id: id, date: date });
                try {
                    const res = await fetch('/Calendar/MoveDate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: body.toString()
                    });
                    if (res.ok) {
                        if (typeof showToast === 'function') showToast('Tehtävä siirretty', date);
                        load();
                    } else if (typeof showToast === 'function') {
                        showToast('Siirto epäonnistui', 'Yritä uudelleen.', 'danger');
                    }
                } catch (err) {
                    alert('Tehtävän siirto epäonnistui.');
                }
            });
        });
    }

    async function load() {
        const params = new URLSearchParams({ year: year });
        const cat = val('fCategory'), site = val('fSite'), group = val('fGroup'), prio = val('fPrio'), mine = document.getElementById('fMine');
        if (cat) params.set('categoryId', cat);
        if (site) params.set('siteId', site);
        if (group) params.set('groupId', group);
        if (prio !== '') params.set('prio', prio);
        if (mine && mine.checked) params.set('mine', 'true');

        const res = await fetch('/Calendar/Data?' + params.toString());
        if (!res.ok) { grid.innerHTML = '<div class="alert alert-danger">Vuosikellon lataus epäonnistui.</div>'; return; }
        const data = await res.json();
        render(data);
    }

    // --- Tapahtumat ---
    document.getElementById('yearPrev').addEventListener('click', function () { year--; load(); });
    document.getElementById('yearNext').addEventListener('click', function () { year++; load(); });
    document.getElementById('yearToday').addEventListener('click', function () { year = new Date().getFullYear(); load(); });
    ['fCategory', 'fSite', 'fGroup', 'fPrio'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', load);
    });
    const mine = document.getElementById('fMine');
    if (mine) mine.addEventListener('change', load);
    const apply = document.getElementById('fApply');
    if (apply) apply.addEventListener('click', load);

    // Reaaliaikainen päivitys SignalR:llä
    window.addEventListener('hubready', function () {
        workHub.on('taskUpdated', function () {
            clearTimeout(refreshTimer);
            refreshTimer = setTimeout(load, 800);
        });
    });

    load();
})();